/** 
 * low level Java/R Interface
 */
package org.rosuda.JRI ;

