/**
 * Generated as part of testing rjava internal java tools
 */
public class TestException extends Exception{
	public TestException(String message){super(message);}
}
	
