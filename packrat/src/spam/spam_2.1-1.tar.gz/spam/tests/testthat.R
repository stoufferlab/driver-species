library("testthat")
library("spam")

test_check("spam")
