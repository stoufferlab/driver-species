.onLoad <- function(libname, pkgname) {

.jinit(parameters="-XmX512m",force.init=TRUE)
.jpackage(pkgname)
  
}  
