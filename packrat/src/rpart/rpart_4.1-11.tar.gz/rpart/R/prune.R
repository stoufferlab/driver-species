# This should be part of Splus proper -- make prune a method
prune <- function(tree, ...)  UseMethod("prune")
