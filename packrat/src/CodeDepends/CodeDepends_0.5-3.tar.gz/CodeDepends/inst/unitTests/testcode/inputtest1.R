{
a = rnorm(n)
b = rnorm(n, a)

plot(a, b+c, main = titletxt)
}
