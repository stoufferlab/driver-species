df %>% f1 %>% f2(opt = z) %>% stats::f3 %>% graphics::f4(opt2 = w, opt3 = "hi") -> out
