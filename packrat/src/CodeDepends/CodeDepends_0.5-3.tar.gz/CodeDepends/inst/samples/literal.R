x = TRUE
y = FALSE

z = x | y

a = T
b = F

c = a | b


x = list(name = 1, id = 2)
{
p = x$name + 2
p1 = x[["name"]] + 3
}

var = "name"
p2 = x[[var]] + 3

