x = list(a = 1, b = 2)
x$a
x$a = 10
x$b
