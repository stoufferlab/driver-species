### R code from vignette source 'actuar.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: actuar.Rnw:109-111 (eval = FALSE)
###################################################
## vignette(package = "actuar")
## demo(package = "actuar")


###################################################
### code chunk number 2: actuar.Rnw:126-128 (eval = FALSE)
###################################################
## citation()
## citation("actuar")


