# Optionally use this file to remove all your results.
# On the next make(), your workflow will start over from scratch.

drake::clean(destroy = TRUE) # destroy = TRUE removes the .drake/ folder too.
unlink(c("report.html", "figure", "Rplots.pdf"), recursive = TRUE)
