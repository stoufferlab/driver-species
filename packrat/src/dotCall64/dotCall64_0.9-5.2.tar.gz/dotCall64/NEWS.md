# dotCall64

# 0.9-5.2
commit c184c8a9e883ccc3b5afe3d5639d689724f71176
Author: Florian Gerber <florian.gerber@math.uzh.ch>
Date:   Thu Jan 11 17:14:48 2018 +0100
* improve documentation


# 0.9-5
commit 1cfc4937b52fcad0ce6bf28b246cec289c15d07d
Author: Florian Gerber <florian.gerber@math.uzh.ch>
Date:   Tue Dec 5 21:37:52 2017 +0100
* debian patch
* update references
* register native routines

# 0.9-4

* CRAN release. 