library(testthat)
library(latex2exp)

test_check("latex2exp")
