.onLoad <-
function(libname, pkgname)
{
    fuzzy_logic("Zadeh")
}
